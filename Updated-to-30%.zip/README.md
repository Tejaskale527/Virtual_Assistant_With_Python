# AI-assistant-in-python-The-Junior
Developed By Rahul Paithane !.AI assistant in python [The Junior]. With Some Security Features Such As AI Name Verification First., this is the demo of our project ,we have added many new features to it like password verification,find loaction,send mail,write note,etc.

[![Demo Video of Junior Assistant](Junior.png)](https://www.youtube.com/watch?v=jJ6_zIAxnn8&t=57s)


## say "Hey Junior"

to start the assistant,virtual assistant will start

to stop the virtual assistant say "stop " ,

it will not terminate the program it will keep running but there will be no response from the assistant , whenever you say "Hey Junior" ,it will start again 


## Demo Version
some queries:

say " Who Invented You"

say "System address" to get the mac address of your computer

say "What is ipaddress" # to get the ip of your computer

say "Open Chrome" # to open the chrome browser on your computer

say "wireless network passwords" to get the wireless network saved passwords

and many more.


************************************************
## say "Hey Junior"

to start the assistant 

it will ask the password **say "Unquie Is the password"** [ Only In Full Version ]

and virtual assistant will start

to stop the virtual assistant say "stop " , it will not terminate the program it will keep running but there will be no response from the assistant , whenever you say "Hey Junior" ,it will start again 

******************************************************

## Full Version  [ Contact Us For Full Version ]

some queries:

say " Who Invented You"

say "Calculate [Your problem] for example say "Calculate 2+2""

say "What is ipaddress" # to get the ip of your computer

say " send mail" # to send a mail ,it is in beta

say " your query wikipedia" for example "Akashy kumar wikipeda" gives in information of akashy sir

say "Where is city_name" Give The Location of the city given

say "Take a photo" to catpure a photo

say "System address" to get the mac address of your computer

say "write a note" to write a note

say"show note" to show the saved note

say "log off" or say "sign out" to sign out your computer

say "tell a joke " Junior assistant say a joke for you

say  "Time" to get the current time

say "wireless network passwords" to get the wireless network saved passwords

say "where I am" to get your current location 

and many more



