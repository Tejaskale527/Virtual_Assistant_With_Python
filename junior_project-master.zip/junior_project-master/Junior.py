import pyttsx3 #install li
import datetime
import speech_recognition as sr #installl li
import wikipedia #install
import webbrowser
import os
import wolframalpha 
import socket
import sys
import requests
import subprocess #wifi pass
import uuid #mac add
from ecapture import ecapture as ec 
import ctypes 
import time 
import pyjokes 
import smtplib#email
from clint.textui import *#color text
import ctypes
import openai
print("*********************************************************************************************************************")     

logo='''     _             _
    | |_   _ _ __ (_) ___  _ __
 _  | | | | | '_ \| |/ _ \| '__|
| |_| | |_| | | | | | (_) | |
 \___/ \__,_|_| |_|_|\___/|_|

 _____ _           __     ___      _               _
|_   _| |__   ___  \ \   / (_)_ __| |_ _   _  __ _| |
  | | | '_ \ / _ \  \ \ / /| | '__| __| | | |/ _` | |
  | | | | | |  __/   \ V / | | |  | |_| |_| | (_| | |
  |_| |_| |_|\___|    \_/  |_|_|   \__|\__,_|\__,_|_|

    _            _     _              _
   / \   ___ ___(_)___| |_ __ _ _ __ | |_
  / _ \ / __/ __| / __| __/ _` | '_ \| __|
 / ___ \\__ \__ \ \__ \ || (_| | | | | |_
/_/   \_\___/___/_|___/\__\__,_|_| |_|\__|'''
print(colored.green(logo))  

print("*********************************************************************************************************************\n")      
                                           
####################################################################################################################################
                    

   
def how_can_i():
    speak("Verification Successfull! Thank You Sir!")
    speak("How Can I help you ?")
def speak(audio):
    engine.say(audio)
    engine.runAndWait()

def wishMe():
        hour = int(datetime.datetime.now().hour)
        if hour>=0 and hour<12:
            speak("Good morning Sir")
            speak("What's The Password!")
        elif hour>=12 and hour<4:
            speak("Good afternoon Sir")
            speak("What's The Password!")
        else:
            speak("Good Evening Sir")
            speak("What's The Password!")
def takeCommand1():
        # takes my command from microphone and gives text
        r =sr.Recognizer()
        try :
            with sr.Microphone() as source:
                print("listening......")
                r.pause_threshold = 1
                audio = r.listen(source)
        except Exception:
            ctypes.windll.user32.MessageBoxW(0, 'The Is no microphone Connected to your Computer.\nIf there is a microphone connected restart the program.', 'Junior - The Virtual Assistant', 0)
            sys.exit()
        try:
            print("recognizing.....")
            query = r.recognize_google(audio, language ='en-in')
            print("query said : ", query)
        except Exception as e:
            print(e)
            print("What's the Name!!")
            return "None"
        return query
def takeCommand2():
        # takes my command from microphone and gives text
        r =sr.Recognizer()
        try :
            with sr.Microphone() as source:
                print("listening......")
                r.pause_threshold = 1
                audio = r.listen(source)
        except Exception:
            ctypes.windll.user32.MessageBoxW(0, 'The Is no microphone Connected to your Computer.\nIf there is a microphone connected restart the program.', 'Junior - The Virtual Assistant', 0)
            sys.exit()
        try:
            print("recognizing.....")
            query = r.recognize_google(audio, language ='en-in')
            print("query said : ", query)
        except Exception as e:
            print(e)
            print("What's the Name!!")
            return "None"
        return query
engine = pyttsx3.init('sapi5')
voices = engine.getProperty('voices')
# print(voices[1].id)
engine.setProperty('voice', voices[1].id)


#mac
mac= (hex(uuid.getnode()))

#wifi password
data = subprocess.check_output(['netsh', 'wlan', 'show', 'profiles']).decode('utf-8').split('\n') #all profile
profiles = [i.split(":")[1][1:-1] for i in data if "All User Profile" in i]#slpit


openai.api_key="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"

completion=openai.Completion()

def Reply(question):
    print("searching")
    prompt=f'Chando: {question}\n Jarvis: '
    response=completion.create(prompt=prompt, engine="text-davinci-002", stop=['\Chando'], max_tokens=200)
    print("done")
    answer=response.choices[0].text.strip()
    return answer

def sendEmail(to, content): 
    server = smtplib.SMTP('smtp.gmail.com', 587) 
    server.ehlo() 
    server.starttls() 
      
    # Enable low security in gmail 
    server.login('shiv.blackhat@gmail.com', '1715460058') 
    server.sendmail('shiv.blackhat@gmail.com', to, content) 
    server.close()

def JuniorTheBot():
    run_once=0
    how=0
    #For INfinity Loop
    while True:
        '''engine = pyttsx3.init('sapi5')
        voices = engine.getProperty('voices')
        # print(voices[1].id)
        engine.setProperty('voice', voices[0].id)'''

        query = takeCommand1().lower()
        wake=""
        wake=query
        wake.strip()
        wake.lower()
        #print(wake)
        #Assistant Name
        while "junior" in wake:

            def takeCommand():
        # takes my command from microphone and gives text
                r =sr.Recognizer()
                with sr.Microphone() as source:
                    print("listening......")
                    r.pause_threshold = 1
                    audio = r.listen(source)
                try:
                    print("recognizing.....")
                    query = r.recognize_google(audio, language ='en-in')
                    print("query said : ", query)
                except Exception as e:
                    print(e)
                    speak("Sorry Sir, can you repeat that again?")
                    return "None"
                return query
            #Wish Function run Once
            if run_once == 0:
                wishMe()
                run_once=1
            # speak("I am your Assistant FRIDAY")

            #Start Of Main Function
            if __name__ == "__main__":
                    query1 = takeCommand2().lower()
                    wake1=""
                    wake1=query1
                    wake1.strip()
                    wake1.lower()
                #Password Logic
                    while "unique" in wake1:

                        if how==0:
                            how_can_i()
                            how = 1
                        elif how==1:
                            speak("Next Command Please ?")
                            how = 3

            
                        query = takeCommand().lower()
     

                        if 'ip address' in query:
                            speak("Finding")
                            hname = socket.gethostname()
                            results = socket.gethostbyname(hname)
                            print(hname)
                            print(results)
                            speak('Host name is:')
                            speak(hname)
                            speak('IP address is :')
                            speak(results)
                           # break
                        
                        elif 'search' in query:
                            query = query.replace("search", "")           
                            webbrowser.open(query)
                            speak('data is showned in browser')


                        elif 'wikipedia' in query:
                            speak("searching in wikipedia")
                            query = query.replace("wikipedia", "")
                            results = wikipedia.summary(query, sentences = 4)
                            speak("According to wikipedia")
                            print(results)
                            speak(results)
    

                        elif "where is" in query: 
                            query = query.replace("where is", "") 
                            location = query 
                            speak("User asked to Locate") 
                            speak(location) 
                            webbrowser.open("https://www.google.com/maps/place/" + location + "") 
                            speak('data is showned in browser')
  
                        elif "camera" in query or "take a photo" in query: 
                            ec.capture(0, "Junior Camera ", "img.jpg")
                            speak("You are looking cool,sir")
                            speak("image is capture")    

                        elif 'lock window' in query: 
                            speak("locking the system") 
                            ctypes.windll.user32.LockWorkStation() 


                        elif "log off" in query or "sign out" in query: 
                            speak("signing-out") 
                            time.sleep(5) 
                            subprocess.call(["shutdown", "/l"])     

                        elif 'system address' in query:
                            speak('System Mac Addresss is')
                            print('System Mac Addresss is')
                            print(mac)
                            speak(mac)

                        elif "write a note" in query: 
                            speak("What should i write, sir") 
                            note = takeCommand() 
                            file = open('junior.txt', 'w') 
                            speak("Your note has been saved")   
                            file.write(note) 
          
                        elif "show note" in query or "show my note" in query or "show my notes" in query: 
                            speak("Showing your Notes") 
                            file = open("junior.txt", "r")  
                            print(file.read()) 
                            speak(file.read(6)) 

                        elif 'joke' in query: 
                            speak('wait,hmmm')
                            speak(pyjokes.get_joke())
       
                        elif 'send a mail' in query: 
                            try: 
                                speak("What should I say?") 
                                content = takeCommand() 
                                speak("whome should i send")
                                speak("type email address on screen")
                                to=input("Email:-")  
                                #to="xyz@gmail.com"  
                                sendEmail(to, content) 
                                speak("Email has been sent !") 
                            except Exception as e: 
                                print(e) 
                                speak("I am not able to send this email")
                        elif 'open youtube' in query:
                            webbrowser.open("youtube.com")
                            speak("youtube is opened")
                        elif 'open google' in query:
                            webbrowser.open("google.com")
                            speak("google is opened")
                        elif 'open gmail' in query:
                            webbrowser.open("gmail.com")
                            speak("gmail is opened")

                        elif 'play music' in query:
                          
                            music_dir = 'D:\\music.mp3'
                            os.startfile(music_dir)
                            speak("music is being played")
                            

                        elif 'time' in query:
                            strTime = datetime.datetime.now().strftime("%H:%M:%S")
                            print(f"the time is {strTime}")
                            speak(f"the time is {strTime}")
                        elif 'date' in query:
                            now = datetime.datetime.now()
                            speak('Current date and time is:')
                            speak(now)

                        elif 'open code' in query:
                            codepath = "C:\\Users\\Shiv\\AppData\\Local\\Programs\\Microsoft VS Code\\Code.exe"
                            os.startfile(codepath)
                        elif 'close code' in query:
                            os.system("taskkill /f /im Code.exe")
                            speak('closed')        

                        
                        elif 'who invented you' in query:
                            speak("At first I was just an idea, then a bunch of people at Computer Science & Engineering Department put their heads together. And now here I am ! The Junior!")
                        elif 'who are you' in query:
                            speak("I am your Assistant Sir! Junior ")
                            speak("i have all permissions about Devil Security server(DSS) and high-tech security")
                        elif 'open notepad' in query:
                            apppath = "C:\\Program Files\\Notepad++\\notepad++.exe"
                            os.startfile(apppath)
                            speak('Notepad is being started')
                        elif 'close notepad' in query:
                            os.system("taskkill /f /im notepad++.exe")
                            speak('Notepad is closed')
                        elif 'video song' in query:
                            apppath = "E:\\Videos\\DJ Chetas.mp4"
                            os.startfile(apppath)
                            speak('Your favorite song being played, sir')
                        elif 'open files' in query:
                            apppath = "C:\\Windows\\explorer.exe"
                            os.startfile(apppath)
                            speak('Files are being opened')
                        elif 'close file' in query:
                            os.system("taskkill /f /im explorer.exe")
                            speak('File Manager is closed')
                        elif 'open cmd' in query:
                            apppath = "C:\\Windows\\System32\\cmd.exe"
                            os.startfile(apppath)
                            speak('terminal being opened')
                        elif 'close cmd' in query:
                            os.system("Taskkill /f /im cmd.exe")
                            speak('terminal is closed')
                        elif 'open chrome' in query:
                            apppath = "C:\\Program Files (x86)\\Google\\Chrome\\Application\\chrome.exe"
                            os.startfile(apppath)
                            speak('chrome being opened')
                        elif 'close chrome' in query:
                            os.system("taskkill /f /im chrome.exe")
                            speak('Google Chrome is closed')
                        elif 'open paint' in query:
                            apppath = "C:\\Windows\\System32\\mspaint.exe"
                            os.startfile(apppath)
                            speak('Paint being opened')
                        elif 'close the paint' in query:
                            os.system("taskkill /f /im mspaint.exe")
                            speak('Paint is closed')

                        #programming apps
                        elif 'open sublime text' in query:
                            path="C:\\Program Files\\Sublime Text 3\\sublime_text.exe"
                            os.startfile(path)
                            speak('Sublime Text being opened')
                        elif 'close sublime text'in query:
                            os.system("taskkill /f /im sublime_text.exe")
                            speak('Sublime Text is closed')
                        elif 'open netbeans' in query:
                            path="C:\\Program Files\\NetBeans 8.1\\bin\\netbeans.exe"
                            os.startfile(path)
                            speak('NetBeans being opened')
                        elif 'close netbeans'in query:
                            os.system("taskkill /f /im netbeans.exe")
                            speak('NetBeans is closed')

                        elif 'open ms word' in query:
                            path="C:\\Program Files\\Microsoft Office\\Office16\\WINWORD.EXE"
                            os.startfile(path)
                            speak('MS word being opened')
                        elif 'open ms excel' in query:
                            path="C:\\Program Files\\Microsoft Office\\Office16\\EXCEL.EXE"
                            os.startfile(path)
                            speak('MS excel being opened')
                        elif 'open ms power point 'in query:
                            path="C:\\Program Files\\Microsoft Office\\Office16\\POWERPNT.EXE"
                            os.startfile(path)
                            speak('MS power point  being opened')
                        elif 'open skype' in query:
                            path="C:\\Program Files\\Microsoft Office\\Office16\\lync.exe"
                            os.startfile(path)
                            speak('Skype being opened')
                        elif 'Open ms Access' in query:
                            path="C:\\Program Files\\Microsoft Office\\Office16\\MSACCESS.EXE"
                            os.startfile(path)
                            speak('Access being opened')
                        elif 'open ms outlook' in query:
                            path="C:\\Program Files\\Microsoft Office\\Office16\\OUTLOOK.EXE"
                            os.startfile(path)
                            speak('OutLook being opened')
                        elif 'open ms publisher' in query:
                            path="C:\\Program Files\\Microsoft Office\\Office16\\MSPUB.EXE"
                            os.startfile(path)
                            speak('Publisher being opened')
                        elif 'open ms onenote' in query:
                            path="C:\\Program Files\\Microsoft Office\\Office16\\ONENOTE.EXE"
                            os.startfile(path)
                            speak('OneNote being opened')
                        elif 'close ms word' in query:
                            os.system("taskkill /f /im WINWORD.EXE")
                            speak('MS word is closed')
                        elif 'close ms excel' in query:
                            os.system("taskkill /f /im EXCEL.EXE")
                            speak('Excel is closed')
                        elif 'close ms power point' in query:
                            os.system("taskkill /f /im POWERPNT.EXE")
                            speak('Power point is closed')
                        elif 'close Skype' in query:
                            os.system("taskkill /f /im lync.exe")
                            speak('Skype is closed')
                        elif 'close MS Access' in query:
                            os.system("taskkill /f /im MSACCESS.EXE")
                            speak('MS access is closed')
                        elif 'close ms outlook' in query:
                            os.system("taskkill /f /im OUTLOOK.EXE")
                            speak('OutLook is closed')
                        elif 'close ms Publisher' in query:
                            os.system("taskkill /f /im MSPUB.EXE")
                            speak('Publisher is closed')
                        elif 'close ms Onenote' in query:
                            os.system("taskkill /f /im ONENOTE.EXE")
                            speak('OneNote is closed')
                        elif 'wireless network passwords' in query or 'wireless network password' in query:
                            for i in profiles:
                                results = subprocess.check_output(['netsh', 'wlan', 'show', 'profile', i, 'key=clear']).decode('utf-8').split('\n')
                                results = [b.split(":")[1][1:-1] for b in results if "Key Content" in b]
                                try:
                                    print ("{:<30}|  {:<}".format(i, results[0]))

                                except IndexError:
                                    pa1= ("{:<30}|  {:<}".format(i, ""))
                                    print(pa1)
                            speak('Saved Wifi passwords being displayed on your Screen ,Sir')

                        elif 'where I am' in query or 'my current location' in query:
                            app_id = "TJLJ3K-29L94KQWW3"  
                            client = wolframalpha.Client(app_id)  
                            res = client.query(query) 
                            answer = next(res.results).text
                            try:
                                speak('finding')
                                print(answer[1:])
                                speak(answer)
                            except:
                                speak("Not able to find")    
                        elif "what is" in query or 'calculate' in query: 
         
                            app_id = "TJLJ3K-29L94KQWW3"  
                            client = wolframalpha.Client(app_id)  
                            res = client.query(query) 
                            answer = next(res.results).text 
                            try:
                                print(answer)
                                speak(answer)    
                            except:
                                speak("Not found") 
                        elif 'shutdown system'in query or 'power off' in query: 
                            speak("Hold On Sir ! Your system is closeing ") 
                            subprocess.call('shutdown / p /f')        
                        elif 'stop' in query or 'ok stop' in query:
                            speak("see you soon Sir")
                            JuniorTheBot()
                        else:
                            data = Reply(query)
                            print(data)
                            speak(data)           
                    else:
                        speak("Password is Worng!")
try:
    JuniorTheBot()
except Exception:
    ctypes.windll.user32.MessageBoxW(0, 'Something Went Wrong ! Try-again\n If You Still Get The Problem Try Uninstalling and Install The Program Again', 'Junior - The Virtual Assistant', 0)
    sys.exit()
